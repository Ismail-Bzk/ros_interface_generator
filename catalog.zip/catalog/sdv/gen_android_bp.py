TEMPLATE="""
rust_protobuf {{
    name: "libcatalog_ampere_{dir}",
    crate_name: "catalog_ampere_{dir}",
    protos: [
        ":catalog_ampere_{dir}",
    ],
    source_stem: "catalog_ampere_{dir}_source",

    rustlibs: [
        "libvsidl_v1_stdlib_diag_proto_rs",
        "libvsidl_v1_stdlib_proto_rs",
        "libsdvsidl_syntax_v1",
        "libcatalog_ampere_common"
    ],
    flags: [
       "-C codegen-units=16",
        "-C opt-level=2",
    ],
    proto_flags: [
        "-I external/protobuf/src",
    ],

    apex_available: [
        "//apex_available:platform",
        "//apex_available:anyapex",
    ],
    host_supported: true,
    vendor_available: true,
    product_available: true,
}}
"""
import os
def gen_android_bp():
    for dir in os.listdir("."):
        print(dir)
        if os.path.isdir(dir):
            android_b = os.path.join(dir, "Android.b")
            with open(android_b, "w") as f:
                f.write(TEMPLATE.format(dir=dir))

gen_android_bp()
